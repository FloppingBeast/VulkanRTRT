lawrence.winters@digipen.edu

Completed Project 4 Part A

- There are two seperate videos, one marked diffuse and one marked BRDF

-- Video marked DIFFUSE contains the monte carlo algorithm with only the diffuse portion of the lighting calculation
-- Video marked BRDF contains algorithm with full BRDF implementation (used GGX for lighting)

** IMPORTANT NOTE **
I made two seperate videos to ensure the algorithm was demonstrated properly as I was unable to remove "fireflies" appearing when including the BRDF into my calculation.